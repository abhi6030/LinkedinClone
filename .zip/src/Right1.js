import "./Right1.css";

function Right1(){
    return(
        <div>
      
       <div className="Lists">

      </div>
      </div>
    );
}
export default Right1;