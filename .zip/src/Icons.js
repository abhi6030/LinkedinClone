import React from 'react';
import { Notifications,Message, Dialpad } from '@material-ui/icons';

const Icons = () => {
    return (
      <div>
        <Notifications></Notifications>
          <Message></Message>
          <Dialpad></Dialpad>
      </div>
    );
}

export default Icons;
