
import './App.css';
import Header from './Header';
import Left1 from './Left1';
import Right1 from './Right1';

function App() {
 return(
    <div className='main'>
     <Header/>
     <Left1/>
     
    </div>
 );
}

export default App;
